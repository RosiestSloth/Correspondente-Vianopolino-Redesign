<?php

namespace Yoast\WP\SEO\Exceptions\Indexable;

use Exception;

/**
 * Class Indexable_Exception
 */
abstract class Indexable_Exception extends Exception {

}
