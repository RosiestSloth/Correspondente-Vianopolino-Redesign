document.addEventListener("DOMContentLoaded", function(){ window.addEventListener("DOMContentLoaded", function(){
	var swiper = new Swiper( ".uagb-block-47403e7a .uagb-swiper",
		{"autoplay":{"delay":3000,"disableOnInteraction":false,"pauseOnMouseEnter":true,"stopOnLastSlide":false},"loop":true,"speed":800,"effect":"slide","direction":"horizontal","flipEffect":{"slideShadows":false},"fadeEffect":{"crossFade":true},"pagination":{"el":".uagb-block-47403e7a .swiper-pagination","clickable":true,"hideOnClick":false},"navigation":{"nextEl":".uagb-block-47403e7a .swiper-button-next","prevEl":".uagb-block-47403e7a .swiper-button-prev"}}	);
});

window.addEventListener("DOMContentLoaded", function(){
	var swiper = new Swiper( ".uagb-block-14bffcf5 .uagb-swiper",
		{"autoplay":{"delay":3000,"disableOnInteraction":false,"pauseOnMouseEnter":true,"stopOnLastSlide":false},"loop":true,"speed":800,"effect":"slide","direction":"horizontal","flipEffect":{"slideShadows":false},"fadeEffect":{"crossFade":true},"pagination":{"el":".uagb-block-14bffcf5 .swiper-pagination","clickable":true,"hideOnClick":false},"navigation":{"nextEl":".uagb-block-14bffcf5 .swiper-button-next","prevEl":".uagb-block-14bffcf5 .swiper-button-prev"}}	);
});

 });