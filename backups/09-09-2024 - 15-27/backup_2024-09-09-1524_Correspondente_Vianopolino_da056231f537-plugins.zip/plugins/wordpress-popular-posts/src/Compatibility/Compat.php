<?php
namespace WordPressPopularPosts\Compatibility;

abstract class Compat {
    abstract public function init();
}
