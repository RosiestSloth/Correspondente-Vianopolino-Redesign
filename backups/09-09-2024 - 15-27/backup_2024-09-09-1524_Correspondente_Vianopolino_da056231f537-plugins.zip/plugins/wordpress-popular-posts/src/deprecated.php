<?php
/**
 * Deprecated functions.
 */

/**
 * Deprecated classes.
 */
