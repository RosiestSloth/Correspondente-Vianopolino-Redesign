<?php return array('dependencies' => array(), 'version' => '564e849071d1694f7137');
